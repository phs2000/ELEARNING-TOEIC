<?php 
    
        $conn = mysqli_connect("localhost", "root","","eff");
        mysqli_set_charset($conn,"utf8");
        if (isset($_FILES['submit']))
        {
            // Nếu file upload không bị lỗi,
            // Tức là thuộc tính error > 0
            
                // Upload file
            
    
                $holot = $_POST['holot'];
                $ten = $_POST['ten'];
                $contact = $_POST['contact'];
                $email = $_POST['email'];
                
                $sql="Update users set holot='$holot', ten='$ten', contact='$contact',email='$email' where username=".$_session['username'];
                // echo  $mk;
                if (mysqli_query($conn, $sql)) {
                    header('Location: index.php?manage=info');
            
                } else {
                  echo "Error: " . $sql . "<br>" . $conn->error;
                }
            
        }
  
?>