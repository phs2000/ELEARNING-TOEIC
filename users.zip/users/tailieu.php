<div class="team" style="margin: 0">
      <div class="container">
        <div class="row">
    
          <div class="col-md-12">
              <div class="bg-list-file">

              
                    
                            <table id="example1" class="table table-bordered table-striped" >
                                <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Tên tài liệu</th>
                                    <th>File</th>
                                    <th>Ghi chú</th>
                                    
                                </tr>
                                <?php $dem=1;?>
                                </thead>
                                <tbody>  
                                <?php
                                   
                                   
                                    require './connect.php';
                                    $sql="SELECT * from file order by id desc";
                                    $result = $conn->query($sql); 
                                    if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                 
                                    
                                ?>       
                                    <tr>     
                                        
                                        <td><?php echo $dem?></td>    
                                        <td><?php $dem++; echo $row["tieude"] ?></td>
                                        <td> 
                                        
                                            <a href="./admin/process/dowloadfile.php?file=<?php echo $row['add_file'] ?>"><?php echo $row['add_file']?></a> 
                                        
                                        </td>
                                        
                                        <td><?php echo $row["note"] ?></td>
                                        
                                        
                                        </td>
                                    
                                        <?php
                                        
                                        }
                                        }
                                        ?>
                                    </tr>
                                                                       
                                </tbody>                   
                            </table>
                                    
                            
                        
            </div>
            
            
          </div>
          
        </div>
      </div>
    </div> 