  <div class="team" style="margin: 0">
      <div class="container">
        <div class="row">
    
          <div class="col-md-10">
            <input type="button" id="btn1" value="Đổi Backgroud màu đỏ"/>
            <input type="button" id="btn2" value="Đổi Backgroud màu xanh"/>
            <input type="button" id="btn3" value="Đổi Backgroud mặc định"/>
                <script language="javascript">
                    // Lấy 2 button và thẻ div
                    var button1 = document.getElementById("btn1");
                    var button2 = document.getElementById("btn2");
                    var button3 = document.getElementById("btn3");
                    var div = document.getElementById('sub-header');

                    // Thiết lập click cho button 1
                    button1.onclick = function () {
                        div.style.background = "red";
                    };

                    // Thiết lập click cho button 2
                    button2.onclick = function () {
                        div.style.background = "blue";
                    };
                    // Thiết lập click cho button 3
                    button3.onclick = function () {
                        div.style.background = "#a4c639";
                    };
                </script>
                    
            
          </div>
          
        </div>
      </div>
    </div> 