<!-- Page Content 
    <div class="page-heading-user header-text">
      <div class="container">
        <div class="row">
         <div class="col-md-12">
            <h1>Thông tin tài khoản</h1>
            
         
        </div>
      </div>
    </div>-->
  <?php
    include('process/xulyinfo.php');
  ?>
    <div class="team" style="margin: 0; height:900px;">
      <div class="container">
      <div class="row">
          <div class="col-md-9 mb-5" style="background:#fff;">
            <section class="tabs-content p-2" >
              <article id='tabs-1'>
                <div class="row">
                    <div class="col-md-4">
                        
                        <?php
                        if(isset($_SESSION['username'])) // If session is not set then redirect to Login Page
                        {
                        echo '<img src="admin/assets/images/users/'.$_SESSION['hinh'].'"class="rounded-circle" style="width:150px;height:150px">';
                        }
                        ?>
                        <a href="" class="filled-button" style="margin-left:25px">Sửa</a>
                    </div>
                <div class="col-md-8">
                    <section class="content">
                    <div class="row">
                        <!-- left column -->

                        <!-- right column -->
                        <div class="col-md-12">
                        <!-- Horizontal Form -->
                        <div class="box box-info">
                            <div class="box-header with-border">
                            
                            </div><!-- /.box-header -->
                            <!-- form start -->
                            <?php
                                require './connect.php';
                                if(isset($_SESSION['username'])) // If session is not set then redirect to Login Page
                                {  
                                

                            ?>
                            
                            <form class="form-horizontal m-2"  method="POST" action="" enctype="multipart/form-data">
                            <div class="box-body">
                                
                                <div class="form-group">
                                <label for="inputEmail3" class="col-sm-3 control-label">Họ lót</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" name="holot" value="<?php echo $_SESSION["holot"] ?>" required>
                                </div>
                                </div>
                                <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Tên</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" name="name" value="<?php echo $_SESSION["ten"] ?>" required>
                                </div>
                                </div>
                                <!--<div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Username</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" name="username" value="<?php echo $_SESSION["username"] ?>" required>
                                </div>
                                </div>
                                <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" name="password" value="<?php echo $_SESSION["password"] ?>" required>
                                </div>
                                </div>-->
                                <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Contact</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" name="contact" value="<?php echo $_SESSION["contact"] ?>" required>
                                </div>
                                <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" name="email" value="<?php echo $_SESSION["email"] ?>" required>
                                </div>
                                </div>
                                
                                
                                
                                
                            <div class="box-footer">
                                <button type="submit" name="cn" class="btn btn-info pull-right">Chỉnh sửa</button>
                                </div><!-- /.box-body -->
                            </div><!-- /.box-footer -->
                            </form>
                            <?php
                                }
                                
                            
                            ?> 
                        </div><!-- /.box -->
                        <!-- general form elements disabled -->
                        <!-- /.box -->
                        </div><!--/.col (right) -->
                        </div>   <!-- /.row -->
                    </section><!-- /.content -->
                
                </div>
               
              </article>

              
             
            </section>
          </div>

          <div class="col-md-3" >
              <div class="left-side-menu">
                <!--- Sidemenu -->
                <div id="sidebar-menu " >
                    
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="home.php">Cập nhật mật khẩu
                            <span class="sr-only">(current)</span>
                            </a>
                        </li> 
                        <li class="nav-item">
                            <a class="nav-link" href="home.php?manage=test">Cập nhật mật khẩu
                            <span class="sr-only">(current)</span>
                            </a>
                        </li>   
                    </ul>
        
                </div>
                <!-- End Sidebar -->
    
          </div>
      </div>
        </div>
        
    </div>
    